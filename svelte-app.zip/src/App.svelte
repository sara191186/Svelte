<script>
	var welcomeText = "Welcome to Svelte";
</script>
<style>
	h1 {
		color: #da106e;
	}
</style>

<h1>{welcomeText}</h1>
